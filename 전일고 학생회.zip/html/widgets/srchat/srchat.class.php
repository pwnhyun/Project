<?php
    /**
     * @class srchat
     * @author sari (sariputra3@naver.com)
     * @version 219.48
     * @brief srchat
     *
     *
     **/
		function chtmk42($vall) {
		$chtend = strrpos($vall,'/');
		$vall = substr($vall,$chtend + 1);
		$vall = substr($vall,0,-4).substr($vall,-4,2);
		return $vall;
		}

    class srchat extends WidgetHandler {

        /**
         * @brief 위젯의 실행 부분
         * ./widgets/위젯/conf/info.xml에 선언한 extra_vars를 args로 받는다
         * 결과를 만든후 print가 아니라 return 해주어야 한다
         **/
        function proc($args) {
						$_SERVER['HTTP_USER_AGENT'] = strtolower($_SERVER['HTTP_USER_AGENT']);
						$sbot=array('bot','yahoo! slurp','daumoa','twiceler','yeti','bingpreview','baiduspider');
						for($i=0;$i < 7;$i++) {
						if(strpos($_SERVER['HTTP_USER_AGENT'],$sbot[$i]) !== false) return;
						}
            // 템플릿의 스킨 경로를 지정 (skin, colorset에 따른 값을 설정)
						$chtemtc = $this->widget_path;
            $tpl_path = sprintf('%sskins/%s', $chtemtc, $args->skin);
						$chtmanager = $args->chtmanager;
						Context::set('chtsrchat', $args->chtsrchat);
						Context::set('cht_lineht', $args->cht_lineht);
						Context::set('cht_usrwh', $args->cht_usrwh);
						Context::set('cht_contwh', $args->cht_contwh);
						Context::set('chthorizon', $args->chthorizon);
						Context::set('chtwidth', $args->chtwidth);
						Context::set('chtheight', $args->chtheight);
						$chtemtc = str_replace('widgets/srchat/','',$chtemtc);
						Context::set('chtemtc', $chtemtc);
						$cht_wico = $args->cht_wico;
						Context::set('cht_wico', $cht_wico);
						$cht_isadmin = '';
						$chttp = session_id();
            $oModuleModel = &getModel('module');
            $config = $oModuleModel->getModuleConfig('point');
            Context::set('chtlvicn', $config->level_icon);
							if(Context::get('is_logged')) {
								$fp = fopen('files/config/db.config.php','r');
								for($i = 0;$i < 4;$i++) fgets($fp);
								$fsct = fgets($fp);$fsct .= fgets($fp);fclose($fp);
								$fhttp = md5($chttp.$fsct);
								$fsct = md5($fsct.$chttp);
								$logged_info = Context::get('logged_info');
								$logged_srl = $logged_info->member_srl;
								setcookie("c".substr($fhttp,-9),$logged_srl);
								if($cht_wico == 2) {
								$chtgico = $logged_info->group_mark->src;
								if($chtgico) {$chtgico = chtmk42($chtgico)."2";}
								} else if($cht_wico == 3) {
								if($oIconshopModel = &getModel('iconshop')) {
								$icon_image = $oIconshopModel->getMemberIconBySelected($logged_srl);
								$chtgico = $icon_image->file1;
								if($chtgico) {$chtgico = chtmk42($chtgico)."3";}
								}} else if($cht_wico == 4) {
								$chtgico = $logged_info->profile_image->src;
								if($chtgico) {$chtgico = chtmk42($chtgico)."4";}
								}
								if($cht_wico == 1 || (($cht_wico == 3 || $cht_wico == 4) && !$chtgico)) {
								$oPointModel = &getModel('point');
								$point = $oPointModel->getPoint($logged_srl);
								$chtgico = $oPointModel->getLevel($point, $config->level_step);
								}
                setcookie("chtmbr","v".$chtgico);
								$chttp = substr($fhttp,6,12);
								$chtnck = $logged_info->nick_name;
								if($logged_info->is_admin == 'Y') $cht_isadmin = 1;
								if($cht_isadmin || ($chtmanager && strpos(",".$chtmanager.",",",".($logged_info->email_address).",") !== false)) {
									setcookie("c".substr($fsct,20),$chttp);
									if($cht_isadmin) setcookie("c".substr($fsct,0,12),$chttp);
								}
								Context::set('chtnck', $chtnck);

								}
            	$oTemplate = &TemplateHandler::getInstance();
	            return $oTemplate->compile($tpl_path, 'srchat');
        }


    }
?>
