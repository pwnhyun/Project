
var cht_this = null;
var cht_imopn = false;
var cht_obj = null;
var cht_tid = 0;
var chttalert = 0;
var chtualert = 0;
var cht_eeo = 0;
var cht_nxthtml = null;
var cht_nxth_tml = null;
var dph = Array();
var chtunload = false;
var chtuadmico = false;
var chtaablkc = 0;
var chtip = '';
var cht_ico = Array();
var chtisbk = false;
var chtbx = 0;
var xmlhttp = null;
var chtreload = 0;
var chtview = 0;
var chtvimg = 100;
var chtimgmw = 0;
var chtrefresh = 1500;
var chtnextread = null;
var chtparam = '';
var chtismobile = 0;
var chtinterval = 0;
var chtwnext = 0;
var chtuimg = false;
var chtiimg = false;
var chtupdown = 0;
var chtwrtpst = false;
var chtmyself = 0;
var chtimgmk = 0;
var chtblk = 1;
var chttitle = '';
var chtctitle = '';
var chtcallt = 0;
var chtmkadmin = false;
var cht_isadmin = 0;
var chtpnck = 0;
var chtbtcnt = 0;
var chtread = 0;
var chtchange = 0;
var chtchtee = '';
var chtaacc = 0;
var fbdyw = 0;
var chtisblack = 0;
var chtusrinout = 0;
var chteelock = 0;
var chtvban = 0;
var chtncw = 0;
var chtafst = '';
var chtvcolor = 0;
var chtxw = '';
var chtxh = '';
var chticopt = 0;
var chtlgnfw = null;
var chtwnck = '';
var chtnwidth = 60; /* 닉네임란 넓이 */
var chtcwidth = 50; /* 색상선택상자넓이 */
var chtvdate = false;
var chtvtime = true;
var chtvread = '000';
var chtnextnk = " &gt; ";
var chtedir = 'widgets/srchat/';

function dallar(key) {var rtn = document.getElementById(key);if(!rtn) rtn = document.getElementById('cht_none');return rtn;}
function cht_imgview(src) {
var img = dallar('cht_img');
if(src == 0 ||img.style.display == "block") {
img.innerHTML = "";
img.style.display = "none";
dallar('cht_gout').value = '0';
cht_imopn = false;
if(cht_nxthtml) cht_nxt_html();
} else {
var srcu = (src.substr(0, 7) != 'http://' && src.indexOf("&view=") == -1)? chtsrchat + "&amp;view=" + src:src;
if(chtview == 1 || chtisbk) window.open(srcu.replace(/amp;/g,''),'_blank');
else {
setTimeout("cht_imopn = true;",300);
img.style.display = "block";
var imgin = "<img onclick='cht_imgview(0)' src='" + srcu + "' alt=''";
if(chtimgmw > 0) imgin += " style='max-width:" + chtimgmw + "px'";
img.innerHTML = imgin + " />";
}}}
function chtnxg(thsx) {
var thsig = thsx.toLowerCase().indexOf("<span style=");
if(thsig != -1) {
thsx = thsx.substr(thsig);
thsx = thsx.substr(0,thsx.indexOf("</span"));
}
thsig = thsx.lastIndexOf('>');
if(thsig != -1) thsx = thsx.substr(thsig + 1);
return thsx.replace(/·/,'');
}
function getNumberingPath(nno) {
var rno = '';
var no = String(nno);
var len = no.length - 3;
while(len > 0) {
rno += no.substr(len,3) + '/';
no = no.substr(0,len);
len = no.length - 3;
}
no = '000' + no;
rno += no.substr(no.length - 3,3) + '/';
return rno + String(nno);
}
function chtext(ths) {
ths = ths.substr(ths.length -3,2);
if(ths == '.g') return '.gif';
else if(ths == '.p') return '.png';
else if(ths == '.j') return '.jpg';
else return '';
}
function chtwxa(thsx) {
var thxs = '';
var thxx = '';
var thtt = thsx.substr(1,1);
if(thsx.substr(0,1) == '1') thxx += "<img class='ht15' src='" + chtedir + "mobile.gif' />";
if(thtt == '2' && chtuadmico) thxx += "<img class='ht15' src='" + chtedir + "srchat_adm.gif' />";
thsx = thsx.substr(2);
var thss = '';
var thsig = thsx.indexOf("\x1a");
if(thsig != -1) {
thss = thsx.substr(0,thsig);
thsx = thsx.substr(thsig + 1);
thsig = thsx.indexOf("\x1a");
if(thsig != -1) {
thxs = thsx.substr(0,thsig);
thsx = thsx.substr(thsig + 1);
if(thxs != '' && cht_wico != '0') {
if(thxs.substr(thxs.length - 3,1) == '.') {
if(thxs.substr(thxs.length - 1,1) == '2') thxx += "<img class='ht15' src='" + chtemtc + "files/attach/filebox/" + getNumberingPath(thxs.substr(0,thxs.length - 3)) + chtext(thxs) + "' />";
else if(thxs.substr(thxs.length - 1,1) == '4') thxx += "<img class='ht50' src='" + chtemtc + "files/member_extra_info/profile_image/" + getNumberingPath(thxs.substr(0,thxs.length - 3)) + chtext(thxs) + "' />";
else thxx += "<img class='ht15' src='" + chtemtc + "files/iconshop/" + thxs.substr(0,thxs.length - 3) + chtext(thxs) + "' />";
} else thxx += "<img class='ht15' src='" + chtemtc + "modules/point/icons/" + chtlvicn + "/" + thxs + ".gif' />";
}}
if(thss == '') thxx += thsx;
else {thss = getNumberingPath(thss);
if(chtimgmk == 1) thxx += "<img class='ht15' src='" + chtemtc + "files/member_extra_info/image_mark/" + thss + ".gif' />" + thsx;
else if(chtimgmk == 2) thxx += "<span style='display:none'>" + thsx + "</span><img class='ht15' src='" + chtemtc + "files/member_extra_info/image_name/" + thss + ".gif' />";
else thxx += thsx;
}} else thxx += thsx;
if(thtt == '0') thxx = "·" + thxx;
return Array(thxx,thsx,thtt);
}
function chtdmb(dmb) {
var tumb = '';
if(dmb == '1') tumb = "<img class='ht15' name='dumb' src='" + chtedir + "dumb.gif' title='글쓰기 차단됨' />";
return tumb;
}
function chtdelff(f) {
var furl;
var fkl;
if(f.href != '') {
furl = f.href;
fkl = furl.indexOf("down=") + 5;
if(fkl == 4) fkl = furl.indexOf("view=") + 5;
if(fkl == 4) {alert('failure');return false;}
fkl = furl.substr(fkl);
if(fkl.indexOf("&") != -1) fkl = fkl.substr(0,fkl.indexOf("&"));
} else {
furl = String(f.onclick);
furl = furl.substr(furl.indexOf("view=") + 5);
fkl = furl.substr(0,furl.indexOf(')') - 1);
}
return fkl;
}
function chtdelf(ths) {
var fkl =  chtdelff(ths.nextSibling);
cht_kout('',fkl, 2);
}
function cht_vinout(f) {
if(f) {
var uarip = f[2].substr(10);
var uxrip = 'cht_' + uarip;
if(f[1].indexOf("<<") != -1) {
var f1 = chtwxa(f[1].substr(0,f[1].indexOf("<<")));
if(dallar(uxrip).id == uxrip) {
cht_delt(dallar(uxrip).parentNode);
dallar('cht_vstd').value = dallar('cht_vstd').value.replace("," + f1[1] + ",",",");
} else {
while(dallar('cht_vstd').value.indexOf("," + f1[1] + ",") != -1) {dallar('cht_vstd').value.replace("," + f1[1] + ",",",");f1[1] += ".";if(uarip == chtip) dallar('neme').value = f1[1];}
dallar('cht_vstd').value =  dallar('cht_vstd').value + f1[1] + ",";
}
var dtt = document.createElement('dt');
dtt.setAttribute('id',uxrip);
dtt.onclick = function(){cht_whspr(this,2)};
f[3] = parseInt(f[3]);
if(f[3] && fbcolor[f[3]]) dtt.style.color = fbcolor[f[3]];
dtt.innerHTML = f1[0];
var dll = document.createElement('dl');
dll.appendChild(dtt);
dtt = document.createElement('dd');
dll.appendChild(dtt);
dallar('cht_DD').firstChild.appendChild(dll);
} else if(f[1].indexOf(">>") != -1) {
if(dallar(uxrip).id == uxrip) cht_delt(dallar(uxrip).parentNode);
var f1 = chtwxa(f[1].substr(0,f[1].indexOf(">>")));
dallar('cht_vstd').value = dallar('cht_vstd').value.replace("," + f1[1] + ",",",");
} else if(f[1].indexOf("<>") != -1) {
if(dallar(uxrip).id == uxrip) {
var ynm = f[1].substr(0,f[1].indexOf("<>"));
var znm = f[1].substr(f[1].indexOf("<>") + 2);
dallar(uxrip).innerHTML = dallar(uxrip).innerHTML.replace(ynm,znm);
dallar('cht_vstd').value = dallar('cht_vstd').value.replace("," + ynm + ",","," + znm + ",");
}} else if(f[1].indexOf("<%>") != -1) {
if(f[1].substr(0,5) == "<%>cx") {
var usrxdv = dallar(f[1].substr(3));
if(usrxdv) cht_delt(usrxdv);
} else if(dallar(uxrip).id == uxrip) {
var gp = f[1].substr(3);
if(gp == '4') {dallar(uxrip).innerHTML = "<img class='ht15' name='dumb' src='" + chtedir + "dumb.gif' title='글쓰기 차단됨' />" + dallar(uxrip).innerHTML;if(uarip == chtip) mkdumb(1);}
else if(gp == '5') {if(dallar(uxrip).firstChild && dallar(uxrip).firstChild.name == 'dumb') cht_delt(dallar(uxrip).firstChild);if(uarip == chtip) mkdumb(0);}
else if(gp == '3') {
if(dallar(uxrip).title != '') {dallar(uxrip).style.color = fbcolor[f[3]];dallar(uxrip).title = '';}
else {dallar(uxrip).style.color = '#BABABA';dallar(uxrip).title = '자리비움';}
}}}
}}
function cht_mdhis(val) {
return val.substr(0,2) + "-" + val.substr(2,2) + " " + val.substr(4,2) + ":" + val.substr(6,2) + ":" + val.substr(8,2);
}
function cht_his(val) {
return val.substr(4,2) + ":" + val.substr(6,2) + ":" + val.substr(8,2);
}
function cht_tntc(fv,nn) {
var rtn = "<div id='cx" + fv[2] + fv[4] + "' class='cht_ntc' style='" + chtafst + "'";
if(nn == 1) {
rtn += " onmouseover='cht_en(\"" + cht_mdhis(fv[2]) + "\")' onmouseout='cht_en()'><span";
if(cht_isadmin != 0) rtn += " onclick='chtxdel(this,\"" + fv[4] + "\")'";
} else rtn += "><span";
rtn += ">▶ </span>";
var f = fv[1];
if(f) {
if(f.substr(0,3) == '<%>') {if(f.substr(0,4) == '<%>b' && dallar('cht_ntim').value != "0000000000a") {
var uyrip = fv[2].substr(10);
if(chtip == uyrip) {tout();location.reload();}
if(dallar('cht_' + uyrip).id != 'cnt_none') cht_delt(dallar('cht_' + uyrip).parentNode);
if(chtvban === 0) rtn = "";else rtn += "<span class='dv'>" + f.substr(4) + "<\/span>님이 강퇴되셨습니다.";
} else rtn = "";
} else if(f.substr(0,3) == '<a>') {rtn += "<span class='dv'>" + f.substr(3) + "<\/span>님이 관리자로 선정되셨습니다. <input type='button' class='cht_button' value='새로고침' onclick='tout();location.reload()' />이 필요합니다.";}
else if(f.substr(0,6) == '<c><x>') {rtn += "<span class='dv'>" + f.substr(6) + "<\/span>님을 호출하셨습니다.";}
else if(f.substr(0,6) == '<h><x>') {rtn += "<span class='dv'>" + f.substr(6) + "<\/span>님이 호출하셨습니다.";}
else if(f.substr(0,6) == '<t><x>') {rtn += "<span class='dv'>" + f.substr(6) + "<\/span>님에게 1:1 대화가 신청되었습니다.";}
else if(f.substr(0,6) == '<r><x>') {uyrip = f.substr(6).split('<>');rtn += "<span class='dv'>" + uyrip[0] + "<\/span>님의 1:1 대화신청을 <span class='dv'>" + uyrip[1] + "<\/span>님이 거절하셨습니다.";}
else if(f.substr(0,6) == '<p><x>') {uyrip = f.substr(6).split('<>');nn = chtsrchat.indexOf('=');rtn += "<span class='dv'>" + uyrip[0] + "<\/span>님의 1:1 대화신청을 <span class='dv'>" + uyrip[1] + "<\/span>님이 수락하셨습니다.<br \/> <a target='_blank' href='" + chtsrchat.substr(0,nn) + "=" + uyrip[2] + "' onmousedown=\"cht_deltt(cht_this=this);cht_go('ssetiq')\"> <b>여기를</b> 클릭하세요</a>";}
else if(f.substr(0,9) == '<q><x><h>') {uyrip = f.substr(9).split('<>');nn = chtsrchat.indexOf('=');rtn += "<span class='dv'>" + uyrip[0] + "<\/span>님에게 <span class='dv'>" + uyrip[1] + "<\/span>님이 1:1 대화를 신청하셨습니다.<br \/> <a target='_blank' href='" + chtsrchat.substr(0,nn) + "=__" + uyrip[2] + "&amp;mkcht=1' onmousedown=\"cht_deltt(cht_this=this);cht_obj.value='" + uyrip[3] + uyrip[1] + "//whisper//11chat//whisper//__" + uyrip[2] + "';cht_go('rpage');cht_go('ssetiq')\"> <b>수락</b> </a> 또는 <a onmousedown=\"cht_deltt(cht_this=this);cht_obj.value='" + uyrip[3] + uyrip[1] + "//whisper//11chat//whisper//xx';cht_go('rpage');\"> <b>거절</b> </a>";}
else if(f.substr(0,3) == '<w>') {uyrip = f.substr(3).split('<>');rtn += "<span class='dv'>" + uyrip[0] + "<\/span>님에게 <span class='dv'>" + uyrip[1] + "<\/span>님의 귓속말<br \/> " + uyrip[2];}
else if(f.substr(f.length-2,2) == '<<') {if(chtusrinout === 0) rtn = "";else {f = f.substr(0,f.length-2);rtn += "<span class='dv'>" + chtwxa(f)[0] + "<\/span>님이 입장하셨습니다.";}}
else if(f.substr(f.length-2,2) == '>>') {if(chtusrinout === 0) rtn = "";else {f = f.substr(0,f.length-2);rtn += "<span class='dv'>" + chtwxa(f)[0] + "<\/span>님이 퇴장하셨습니다.";}}
else if(f.indexOf("<>") != -1) {if(chtchange === 0) rtn = "";else rtn += "<span class='dv'>" + f.replace(/([^<]+)<>/,"$1<\/span>  → <span class='dv'>") + "<\/span> (으)로 바꿨습니다.";}
else if(nn == 2 && (f.indexOf("<span  class='dv'>") != -1 || f.indexOf("<span class='dv' >") != -1)) rtn = "";
else rtn += f;
if(rtn != "") {
rtn += "</div><div class='bx'><\/div>";
}} else rtn = "";
return rtn;
}
function cht_tico(f) {
if(f) {
if(f.indexOf('<f>') === 0) {
var ff = f.substr(6).split('<>');
var vd = (f.indexOf('<v>') === 3)? 'view':'down';
if(cht_isadmin != 0) f = "<input type='button' value='삭제' class='cht_button' onclick='chtdelf(this)' style='margin-right:10px;height:18px' /><a ";else f = "<a ";
var elnk = chtsrchat + "&amp;" + vd + "=" + ff[0];
if(chtview == 1 || vd == 'down' || (chtview == 2 && chtuimg)) f += "target='_blank' href='" + elnk + "'";
else f += "onclick='cht_imgview(\"" + elnk + "\")'";
if(vd == 'view' && !chtuimg) {
if(!!ff[2]) var elnkk = chtsrchat + "&amp;" + vd + "=" + ff[2];else var elnkk = elnk;
f += "><img style='max-width:" + chtvimg + "px' src='" + elnkk + "' \/";
if(chtview == 2) f += "><\/a><a target='_blank' href='" + elnk + "'";
} f += ">" + ff[1] + "<\/a>";
} else {
if(f.indexOf("http:") != -1 || f.indexOf("https:") != -1 || f.indexOf("ftp:") != -1) {
if(chtiimg) f = f.replace(/(http|https|ftp):\/\/([^"'<>\r\n\s]+)\/([^"'<>\r\n\s\/]+)\.(jpg|gif|png|bmp|jpeg)/gi,"<a " + ((chtview != 0 || chtisbk)?"target='_blank' href='$1:\\$2/$3.$4'":"onclick='cht_imgview(this.innerHTML.replace(/amp;/g,\"\"))'") + ">$1:\\$2/$3.$4</a>");
else f = f.replace(/(http|https|ftp):\/\/([^"'<>\r\n\s]+)\/([^"'<>\r\n\s\/]+)\.(jpg|gif|png|bmp|jpeg)/gi,"<a " + ((chtview == 1 || chtisbk)?"target='_blank' href='$1:\\$2/$3.$4'":"onclick='cht_imgview(this.firstChild.src.replace(/amp;/g,\"\"))'") + "><img" + ((chtvimg > 0)?" style='max-width:" + chtvimg + "px'":"") + " src='$1:\\$2/$3.$4' />" + ((chtview == 2)? "</a><a target='_blank' href='$1:\\$2/$3.$4'>":"") + "$3.$4</a>");
f = f.replace(/(http|https|ftp):\/\/([^"'<>\r\n\s]+)/gi,"<a target='_blank' href='$1://$2'>$1://$2</a>").replace(/:\\/gi,"://");
} else if(cht_ico.length > 0 && f.indexOf("▩") != -1 && f.indexOf(".") != -1) {
var g = f.split("▩");
var gl = g.length;
var fl = -1;
f = g[0];
for(var i=1;i < gl;i++) {
fl = g[i].indexOf(".");
if(fl != -1) {
var gfl = g[i].substr(0,fl).split(",");
if(gfl[1]) f += "<img src='" + chtedir + "emoticon" + cht_ico[gfl[0]][0] + cht_ico[gfl[0]][gfl[1]] + "' alt='' />";
f += g[i].substr(fl + 1);
} else f += "#" + g[i];
}}}}
return f;
}
var fbcolor = Array("#000000","#000000","#7d7d7d","#ff0000","#8c4835","#ff6c00","#ff9900","#ffef00","#a6cf00","#009e25","#1c4827","#00b0a2","#00ccff","#0095ff","#0075c8","#3a32c3","#7820b9","#ef007c");

function cht_fdnm(fdnm) {
var retunr;
var chtdda = dallar('cht_DD').getElementsByTagName('dt');
if(chtdda && chtdda.length > 0) {
for(var i = chtdda.length -1;i >= 0; i--) {
if(fdnm == chtnxg(chtdda[i].innerHTML)) {
retunr = chtdda[i];
break;
}}}
return retunr;
}
function ckt_whspr(ths,uzrip) {
if(chtsrchat.indexOf("__") != -1) return false;
cht_ntm(ths.parentNode);
var thh = ths.parentNode.nextSibling;
if(cht_imopn) cht_imgview(0);
if(cht_nxthtml != thh) {
var thst = chtnxg(ths.innerHTML);
if(thst) {
var uzrip = ths.parentNode.id.substr(12,12);
if(dallar('cht_' + uzrip).id != 'cht_none') {
if(cht_whspr(dallar('cht_' + uzrip),1,thh)) {
if(chtupdown != 1) setTimeout("dallar('cht_AA').scrollTop = dallar('cht_AA').scrollHeight;",50);
}} else cht_in("<b>" + thst + "</b> 님이 자리에 없습니다.");
}}}
function cht_ntm(ths,ntm) {
if(ntm) {
var iscnnctdd = '';
var iscnnctd = chtnxg(ths.firstChild.innerHTML);
if(fbdyw > 209) {iscnnctdd += '<div style="float:left;white-space:nowrap;overflow:hidden;font-weight:bold;max-width:' + (fbdyw - 189) + 'px;">' + iscnnctd + '</div>';}
var ntmdiv = dallar('cht_' + ths.id.substr(12,12));
iscnnctdd += (ntmdiv.id != 'cht_none')? ' :: 접속중':' :: 부재중';
ths.style.background = (chtisblack == 1)? '#212121':'#E9FFE3';
cht_en(iscnnctdd + " (" + cht_mdhis(ths.id.substr(2)) + ")&nbsp;");
} else {
cht_en();
ths.style.background = '';
}}
function cht_tosty(cont,cn) {
if(!cont[2]) return '';
var usrip = cont[2].substr(10);
var usrhis = cont[2].substr(0,10);
var usrvv = dallar('cht_' + usrip);
if(cont[3] && fbcolor[cont[3]]) cont[3] = 'color:' + fbcolor[cont[3]];
else cont[3] = '';
var chtwxaa = chtwxa(cont[0]);
cont[0] = chtwxaa[0];
cont[1] = cht_tico(cont[1]);
var cont4 = '';
if(!chtisbk) {
var cont5 = '';contr = '';
if(usrvv.id != 'cht_none') {if(!!cont[0]) {if(!usrvv.firstChild || !usrvv.firstChild.name || usrvv.firstChild.name != 'dumb') {dallar('cht_vstd').value = dallar('cht_vstd').value.replace("," + chtnxg(usrvv.innerHTML) + ",","," + chtwxaa[1] + ",");usrvv.innerHTML = cont[0];}}if(!!cont[3]) usrvv.style.color = cont[3].substr(6);}
if(chtip == usrip) {if(chtmyself == 2) {cont[3] += ";padding-right:4px;text-align:right;";cont[1] = "<span style=\"clear:right\">" + cont[1] + "<\/span>";cont5 = " style=\"float:right\"";cont[0] = "<b onclick=\"cht_whspr(0,3,this)\" style=\"float:right;" + ((cont[0].indexOf("<") == -1)? "":"margin-top:-3px") + "\">" + cont[0];} else {cont[0] = "<b onclick=\"cht_whspr(0,3,this)\">" + cont[0];if(chtmyself == 1) cont4 = (chtisblack == 1)?" myselfb":" myselfw";}}
else if(cn  == '1') cont[0] = "<b>" + cont[0];else cont[0] = "<b onclick=\"ckt_whspr(this,'" + usrip + "')\">" + cont[0];
if(cht_isadmin != 0) cont5 += " onclick=\"chtxdel(this,'" + cont[4] + "')\"";
contr = "<div id=\"cx" + cont[2] + cont[4] + "\" class=\"cx" + cont4 + "\" style=\"" + chtafst + cont[3] + "\" onmouseover=\"cht_ntm(this,1)\" onmouseout=\"cht_ntm(this)\">" + cont[0] + "<\/b><b" + cont5 + ">" + chtnextnk + "<\/b>" + cont[1];
if(chtvdate && (chtmyself != 2 || cont5 == "" || cont5.substr(1,5) != "style")) contr += "<span class=\"chtvdat\">" + cht_his(cont[2]) + "<\/span>";
contr += "<\/div><div class=\"bx\"><\/div>";
return contr;
} else {
cont4 = "<div class='cx' style='" + cont[3] + "'>";
if(cht_isadmin != 0) cont4 += "<input type=\"checkbox\" name=\"xbak[]\" value=\"" + cont[4] + "\" title=\"" + cont[5] + "\" />";
cont4 += " <span class=\"cht8\">&nbsp;" + cht_mdhis(usrhis) + " <\/span>&nbsp; <b>" + cont[0] + chtnextnk + "<\/b>" + cont[1] + "<\/div>";
return cont4;
}}
function cht_fbc(str) {
if(str.substr(0,1) === '0') str = str.substr(1);
return fbcolor[parseInt(str)];
}
function cht_fbcolr(nine) {
var thst = dallar('cht_color');
if(thst.title == '' || thst.title != 'disabled') {
var xx = cht_fbc(thst.value);
if(xx) {
cht_obj.style.color = xx;
dallar('neme').style.color = xx;
thst.style.backgroundColor = xx;
if(nine !== 9) cht_obj.focus();
}}}
function cht_aaee(pxp,xpx) {
if(chthorizon == 'v') {
dallar('cht_DD').style.height = pxp;
dallar('cht_AA').style.height = xpx;
} else {
dallar('cht_DD').style.width = pxp;
dallar('cht_AA').style.width = xpx;
}}
function cht_aadd(vcc) {
if(dallar('cht_gout').value != '9') {
var h = parseInt(cht_cntwh) + parseInt(cht_usrwh);
var d = cht_cntwh.replace(/[0-9]+/g,'');
if(d == 'mm') {
cht_cntwh = parseInt(cht_cntwh) + '%';
cht_usrwh = parseInt(cht_usrwh) + '%';
d = '%';
}
if(chthorizon == 'v') {
if(vcc == 0 && dallar('cht_DD').style.height == cht_cntwh) cht_aaee(0,h + d);
else if(vcc == 2 || dallar('cht_DD').style.height == cht_usrwh) {cht_aaee(cht_cntwh,cht_usrwh);chtaacc = vcc;}
else {cht_aaee(cht_usrwh,cht_cntwh);chtaacc = 1;}
} else {
if(dallar('cht_DD').style.width == cht_usrwh) {dallar('cht_DD').style.display = 'none';cht_aaee(0,h + d);}
else {dallar('cht_DD').style.display = 'block';cht_aaee(cht_usrwh,cht_cntwh);}
}
if(chtupdown == 0) dallar('cht_AA').scrollTop = dallar('cht_AA').scrollHeight;
}}
function cht_tag(fvalue) {
if(cht_obj.createTextRange && cht_obj.currentPos && !cht_obj.currentPos.text) cht_obj.currentPos.text = "▩" + fvalue + ".";
else if(cht_obj.selectionStart) cht_obj.value = cht_obj.value.substring(0, cht_obj.selectionStart) + "▩" + fvalue + "." + cht_obj.value.substring(cht_obj.selectionEnd);
else cht_obj.value = cht_obj.value + "▩" + fvalue + ".";
chtemtbk(dallar('cht_LL'));
cht_obj.focus();
}
function notixe(tht) {
if(tht) tht = 'none';
else tht = '';
var cht_ntctr = dallar('cht_AA').getElementsByTagName('div');
for(var i=cht_ntctr.length-1;i >= 0;i--) {if(cht_ntctr[i].className == 'cht_ntc') cht_ntctr[i].style.display = tht;}
}
function cht_toggle(ff) {
var f = dallar(ff);
if(f) {
if(ff == 'cht_chkdiv') {
if(dallar('chtupload').style.display != 'none') dallar('chcontent').style.width = (f.style.display == 'block')? parseInt(dallar('chcontent').style.width) - 18 + 'px':parseInt(dallar('chcontent').style.width) + 18 + 'px';
if(chtwrtpst) {
dallar('cht_UU').style.marginTop = (f.style.display == 'block')? parseInt(dallar('cht_UU').style.marginTop) + 23 + 'px':parseInt(dallar('cht_UU').style.marginTop) - 23 + 'px';
dallar('cht_HH').style.marginTop = (f.style.display == 'block')? parseInt(dallar('cht_HH').style.marginTop) - 23 + 'px':parseInt(dallar('cht_HH').style.marginTop) + 23 + 'px';
}}
if(ff == 'cht_fico' && f.style.display == 'none' && !chtwrtpst && chticopt == 0) {
setTimeout("chticopt = dallar('cht_fico').scrollHeight;var htc = parseInt(chtxh) - chticopt;if(htc > 0) dallar('cht_fico').style.paddingTop = htc + 'px';else if(htc < 0) dallar('cht_fico').innerHTML = dallar('cht_fico').innerHTML + '<img src=\"' + chtedir + 'srchat_e.png\" title=\"close\" onclick=\"chtemtbk(dallar(\\\'cht_LL\\\'))\" />';",100);
}
f.style.display = (f.style.display == 'block')? 'none':'block';
}}
function chtemtbk(emt) {
if(emt.title == 'disabled') return;
if(emt.id == 'cht_LL' || emt.id == 'cht_MM' || emt.id == 'cht_PP' || emt.id == 'cht_QQ' || emt.id == 'cht_SS') {
var tme = '1px';
if(emt.style.borderWidth == '1px') tme = '0px';
emt.style.borderWidth = tme;
emt.style.padding = (tme == '1px')? '0px':'1px';
}
if(emt.id == 'cht_LL') cht_toggle('cht_fico');
else if(emt.id == 'cht_ZZ') cht_toggle('cht_CC');
else {
if(emt.id == 'cht_MM') dallar('chcontent').style.fontWeight=(tme == '1px')? 'bold':'normal';
else if(emt.id == 'cht_PP') dallar('chcontent').style.fontStyle=(tme == '1px')? 'italic':'normal';
else if(emt.id == 'cht_SS') {if(chtupdown != 1) chtupdown = (tme == '1px')? 2:0;}
else if(emt.id == 'cht_WW') {dallar('cht_AA').innerHTML = '';chtbx = 0;}
if(dallar('chtwtfm').style.display != 'none' && chtismobile != 1) cht_obj.focus();
}}
function cht_go(view) {
	clearTimeout(chtnextread);
	if(chtparam != '') {
	if(view == 'read') chtnextread = setTimeout("cht_go('read')", chtrefresh);
	else setTimeout("cht_go('" + view + "')",100);
	} else {
	var cht_ntime = new Date();
	var gtime = cht_ntime.getTime();
	var cht_etiq = Array("",";color:#BABABA' title='자리비움");
	var cht_ntv = dallar('cht_ntim').value.substr(10);
	if(cht_ntv != 'a') cht_ntv = cht_ntv + '&rd=' + chtvread;
	var cht_ok = 9;
	var nam = dallar('neme').value.replace(/[&'"]/gi,"");
	if(view == 'rpage' || view == 'alert') {
	var contt = cht_obj.value;
	if(dallar('cht_fico').style.display == 'block') chtemtbk(dallar('cht_LL'));
	cht_obj.value = '';
	if(contt.substr(0,1) == ';') {
	cht_obj.focus();
	if(contt == ';ico'){if(dallar('cht_LL').title != 'disabled') chtemtbk(dallar('cht_LL'));return;}
	else if(contt == ';b'){if(dallar('cht_MM').title != 'disabled') chtemtbk(dallar('cht_MM'));return;}
	else if(contt == ';i'){if(dallar('cht_PP').title != 'disabled') chtemtbk(dallar('cht_PP'));return;}
	else if(contt == ';u'){if(dallar('cht_QQ').title != 'disabled') chtemtbk(dallar('cht_QQ'));return;}
	else if(contt == ';pause'){if(dallar('cht_SS').title != 'disabled') chtemtbk(dallar('cht_SS'));return;}
	else if(contt == ';re'){if(dallar('cht_RR').title != 'disabled') {tout();location.reload();}return;}
	else if(contt == ';exit'){if(dallar('cht_OO').title != 'disabled') cht_leave();return;}
	else if(contt == ';nick'){if(chtpnck != 2 && chtvcolor != 2) chtvwnck();return;}
	else if(contt == ';clear'){if(dallar('cht_WW').title != 'disabled') chtemtbk(dallar('cht_WW'));return;}
	else if(contt == ';head'){if(dallar('cht_ZZ').title != 'disabled') chtemtbk(dallar('cht_ZZ'));return;}
	else if(contt == ';bak'){if(dallar('chtbackup').innerHTML != 'false') {if(!window.open(chtsrchat + "&v=backup","_blank")) cht_in("<a target='_blank' href='" + chtsrchat + "&amp;v=backup'>전체대화<\/a>");}return;}
	else if(contt == ';admin'){if(dallar('chtadmin').innerHTML != 'false') {if(!window.open(chtsrchat + "&v=ban&admin=1","_blank")) cht_in("<a target='_blank' href='" + chtsrchat + "&amp;v=ban&amp;admin=1'>관리자기능<\/a>");}return;}
	else if(contt == ';color'){if(chtvcolor == 2) chtvwnck();return;}
	} else if((chtpnck == 1 && dallar('chtnecolor').style.width != '1px') || chtvcolor == 2 && dallar('chtnecolor').style.width == (chtnwidth + chtcwidth + 2) + 'px') chtvwnck();
		if(chtinterval > 0) {
	if(chtwnext > gtime) {cht_inn('글쓰기 시간간격 '+ ((chtwnext - gtime)/1000) + '초/' + chtinterval + '초 남았습니다',2000,'cht_alert','');cht_obj.value = contt;cht_obj.focus();return false;}
		chtwnext = gtime + chtinterval*1000;
		}
		if(dallar('cht_pnam').value != nam) {
		if(nam.substr(0,1).replace(/[　\s]/g,"") != "") {
		if(dallar('cht_pnam').value != "") {
		if(dallar('cht_vstd').value.indexOf("," + nam + ",") != -1 || dallar('cht_vstd').value.indexOf(",·" + nam + ",") != -1) {
		cht_ok = 2;
		cht_inn("중복된 '닉네임' 입니다",2000,"cht_alert","");
		dallar('neme').value = dallar('cht_pnam').value;
		}}} else {cht_ok = 2;cht_inn("닉네임 첫글자가 공백입니다",2000,"cht_alert","");}
		if(cht_ok == 9) {dallar('cht_pnam').value = nam;nam += '&nn=' + chtchange;}
		else dallar('neme').value = dallar('cht_pnam').value;
		}
		if(cht_ok == 9) {
		if(view == 'alert') {
		if(chtcallt == 0 || gtime - parseInt(dallar('cht_callt').value) >= chtcallt) cht_ok = 2;
		contt += '//whisper//11chat//whisper//yy';
		} else {
		contt = contt.replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/[\r\n]/g, "").replace(/`/g,"").replace(/%/g,"%25").replace(/&/g,"%26").replace(/\+/g,"%2B").replace(/\\/g,"＼");if(contt =='') return false;
		if(dph.length) {
		for(var i = 0; dph[i]; i++){
		if(dph[i] && contt.indexOf(dph[i]) != -1) {
		cht_ok = 2;
		cht_inn("금지된 표현 '"+ dph[i] +"' (이)가 포함되어 있습니다.",2000,"cht_alert","");
		break;
		}}}}
		if(cht_ok == 9) {
		if(dallar('cht_prev').value != contt) {
		var fstyle = dallar('cht_color').value;
		if(fstyle.title == '' || fstyle.title != 'disabled') {
		if(dallar('psty').value != fstyle) dallar('psty').value = fstyle;
		if(dallar('cht_JJ').style.width != '1px') {
		chtwnck = dallar('cht_wip').value.substr(12) + '//';
		if(contt == chtwnck) {chtipths();return;}
		setTimeout('cht_obj.value = chtwnck;',10);
		cht_ok = contt.indexOf('//');
		if(cht_ok != -1) contt = contt.substr(cht_ok + 2);
		contt = dallar('cht_wip').value + '//whisper//' + contt;
		} else {
		if(dallar('cht_MM').style.borderWidth == '1px') contt = "(b)" + contt;
		if(dallar('cht_PP').style.borderWidth == '1px') contt = "(i)" + contt;
		if(dallar('cht_QQ').style.borderWidth == '1px') contt = "(u)" + contt;
		}
		chtparam = chtsrchat + '&neme='+ nam +'&content='+ contt + '&tt=' + cht_ntv + '&ff=' + fstyle;
		cht_iscookie(fstyle);
		dallar('cht_prev').value = contt;
		dallar('cht_ptim').value = gtime;
		}} else cht_inn('중복된 내용입니다',2000,'cht_alert','');
		}
		}
	} else if(view == 'out') {
		chtparam = chtsrchat + "&content=9579a584&tt=" + cht_ntv;
	} else if(view == 'exit') {
		chtparam = chtsrchat + "&content=8579a584&tt=" + cht_ntv;
	} else if(view == 'ssetiq') {
		chtparam = chtsrchat + "&content=6579a584&tt=" + cht_ntv;
	} else {
		var xtval = (parseInt(dallar('cht_xtim').value) + 1)%10;
		dallar('cht_xtim').value = xtval;
		if(dallar('cht_gout').value == '9') {if(chtbtcnt == 1 && dallar('cht_VV').style.display != 'none') {
		cht_ok = 99;
		if(xtval % 5 == 1) chtparam = chtsrchat + '&tt=number';else chtnextread = setTimeout("cht_go('read')", chtrefresh);
		}} else {
		if(cht_ntv == 'a') chtparam = chtsrchat + '&rr=' + chtread + '&tt=' + cht_ntv + '&neme=' + nam;
		else if(xtval == 0) chtparam = chtsrchat + '&tt=x';
		else chtparam = chtsrchat + '&tt=' + cht_ntv;
	  if(view == 'in') {chtparam += '&content=7579a584';view = 'read';}
	}}
if(chtparam != '') {
if(window.ActiveXObject) {
xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
}  else if(window.XMLHttpRequest) {
xmlhttp = new XMLHttpRequest();
}
xmlhttp.open("POST", chtparam, true);
xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
xmlhttp.onreadystatechange = function(){
if(xmlhttp.readyState=='4' && xmlhttp.status=='200') {
	var str = xmlhttp.responseText;
	if(str.indexOf("<h1>") != -1) {dallar('cht_gout').value = '9';dallar('cht_fbdy').innerHTML=str;dallar('cht_VV').innerHTML='';return false;}
  else if(cht_ok == 99) {
	if(str.substr(0,9) == '<fieldset') location.reload();
	else dallar('cht_VV').firstChild.value = ' 채팅방 접속자 : ' + str;
	} else {
	if(chtvtime) {
	var ts = '';
	var t = cht_ntime.getHours();
	var m = cht_ntime.getMinutes();
	var s = cht_ntime.getSeconds();
	ts += (t < 10)? "0"+t+":":t+":";
	ts += (m < 10)? "0"+m+":":m+":";
	ts += (s < 10)? "0"+s:s;
	dallar('cht_FF').innerHTML = ts;
	}
		var vew = str.split("\x7f");
		if(vew.length > 0 && vew[0] != ''){
			var vews = vew[0].split("\x18");
			var sdd = vews.length - 1;
			var stra = '';var strt = '';
			var strr = '';var vew12 = '';var vew13 = Array();var cht_vstd = ",";
			for(var i = 0;i < sdd;i++) {
			vew12 = vews[i].substr(0,12);
			vew13 = chtwxa(vews[i].substr(16));
			strt = "<dl><dt id='cht_" + vew12 + "' style='color:" + cht_fbc(vews[i].substr(14,2)) + ";" + chtafst + cht_etiq[vews[i].substr(12,1)] + "'";
			if(vew12 == chtip) {strt += " onclick='cht_whspr(this,4)' class='" + ((chtisblack == 1)? "chtselfb":"chtselfw") + "'>";if(vews[i].substr(13,1) == '1') mkdumb(1);else mkdumb(0);}
			else strt += " onclick='cht_whspr(this,2)'>";
			strt += chtdmb(vews[i].substr(13,1)) + vew13[0] + "<\/dt><dd><\/dd><\/dl>";
			if(vew13[2] == 2) stra = strt + stra;
			else if(vew13[2] == 1) stra += strt;
			else strr += strt;
			cht_vstd += vew13[1] + ",";
			}
			dallar('cht_DD').innerHTML = "<div class='dv'>" + stra + strr + "<\/div>";
			dallar('cht_vstd').value = cht_vstd.replace(/·/g,'');
		}
		var strr = "";
		if(vew.length > 1 && vew[1] != ''){
			var aline = vew[1].split("\x18");
			var alinength = aline.length -2;
			if(chtupdown == 1) {
			for(var i = alinength;i >= 0;i--){
			if(aline[i]) {
			var wnam = aline[i].split("\x1b");
			if(i == alinength) chtvread = wnam[4];
			if(wnam[0]) strr += cht_tosty(wnam,0);
			else {
			if(wnam[1].indexOf("<h>") !== -1) chtparam = 'n';
			if(cht_ntv !== 'a' || wnam[1].indexOf("<x>") !== 3) strr += cht_tntc(wnam,1);
			if(cht_ntv !== 'a') cht_vinout(wnam);
			}}}} else {
			for(var i = 0;i <= alinength;i++){
			if(aline[i]) {
			var wnam = aline[i].split("\x1b");
			if(i == alinength) chtvread = wnam[4];
			if(wnam[0]) strr += cht_tosty(wnam,0);
			else {
			if(wnam[1].indexOf("<h>") !== -1) chtparam = 'n';
			if(cht_ntv !== 'a' || wnam[1].indexOf("<x>") !== 3) strr += cht_tntc(wnam,1);
			if(cht_ntv !== 'a') cht_vinout(wnam);
			}}}}
			if(strr != "") {
			if(chtbx > 500 || chtbx == 0) {
			dallar('cht_AA').innerHTML = strr;chtbx = 1;
			} else {
			chtbx++;
			var cdiv = document.createElement("div");
			cdiv.innerHTML = strr;
			cdiv.style.padding = 0;
			cdiv.style.margin = 0;
			if(chtupdown == 1) dallar('cht_AA').insertBefore(cdiv,dallar('cht_AA').firstChild);
			else dallar('cht_AA').appendChild(cdiv);
			}
			if(chtupdown == 1) dallar('cht_AA').scrollTop = 0;
			else if(chtupdown == 0) setTimeout("dallar('cht_AA').scrollTop = dallar('cht_AA').scrollHeight;",50);
			if(strr != '' && cht_ntv != 'a' && chtualert != 5 && (chtparam == 'n' || (chttalert !== 0 && parseInt(gtime) - parseInt(dallar('cht_ptim').value) > chttalert))) {
			if(chtualert == 2 || chtualert == 3 || (chtualert == 4 && chtismobile == 1)) {chttitle=document.title;chtctitle=ts;chtaablkc=gtime;chtblk = 0;chtaablk();}
			if(chtualert == 0 || chtualert == 3 || (chtualert == 4 && chtismobile != 1))  dallar('cht_AA').innerHTML = dallar('cht_AA').innerHTML + "<embed src='" + chtedir + "srchat.swf' type='application/x-shockwave-flash' width='1px' height='1px'><\/embed>";
			}}
			dallar('cht_ptim').value = gtime;
		}
			if(dallar('cht_DD').firstChild) chtchtee = "접속자 (" + dallar('cht_DD').firstChild.childNodes.length + ")";
			if(chteelock == 0) dallar('cht_EE').innerHTML = chtchtee;
	}
	dallar('cht_ntim').value = gtime;
	chtparam = '';
	chtnextread = setTimeout("cht_go('read')", chtrefresh);
	delete xmlhttp;
}}
xmlhttp.send(chtparam);
if(view == 'out') return view;
}
if(view == 'rpage') cht_obj.focus();
}}

function cht_away() {
var ths = '자리비움을 ' + ((dallar('cht_' + chtip).title != '')? '해제':'설정') + '했습니다';
cht_nxth_tml = null;
cht_in(ths);
cht_go('ssetiq');
}
function cht_en(texxt) {
if(texxt) {dallar('cht_EE').innerHTML = "<div class='smll'>" + texxt + "</div>";chteelock = 2;}
else {dallar('cht_EE').innerHTML = chtchtee;chteelock = 0;}
}
function cht_in(texxt) {
if(texxt) {
setTimeout("cht_eeo = 3",1000);
setTimeout("if(cht_eeo == 3) cht_eeo = 2",2000);
setTimeout("cht_in()",4000);
cht_eeo = 0;
cht_en(texxt);
} else if(cht_eeo == 2) {cht_en();cht_eeo = 0;}
}
function cht_inn(texxt,vtm,vclass,vid) {
if(!vid) {vid = 'cht_tid_' + cht_tid;cht_tid++;}
var vdiv = document.createElement("div");
vdiv.innerHTML = texxt.replace(/#34;/g,'"').replace(/#39;/g,"'");
vdiv.id = vid;
if(vclass) vdiv.className = vclass;
if(chtupdown == 1) dallar('cht_AA').insertBefore(vdiv,dallar('cht_AA').firstChild);
else dallar('cht_AA').appendChild(vdiv);
if(vtm) setTimeout("cht_delt(dallar('" + vid + "'))",vtm);
if(chtupdown == 0) dallar('cht_AA').scrollTop = dallar('cht_AA').scrollHeight;
}
function cht_leave() {
cht_go('exit');dallar('cht_gout').value='9';chtlgnfw.chtenter(2);dallar('cht_xtim').value = '5';
}
function chtvwnck() {
if(chtvcolor == 2) {
if(dallar('chtnecolor').offsetWidth < chtnwidth + chtcwidth) {
dallar('chtnecolor').style.width = (chtnwidth + chtcwidth + 2) + 'px';
if(chtncw == 1) dallar('chcontent').style.width = parseInt(parseInt(dallar('chcontent').style.width) - chtcwidth) + 'px';
dallar('cht_color').style.display = 'inline';
} else {
dallar('chtnecolor').style.width = (chtnwidth + 2) + 'px';
if(chtncw == 1) dallar('chcontent').style.width = parseInt(parseInt(dallar('chcontent').style.width) + chtcwidth) + 'px';
dallar('cht_color').style.display = 'none';
}} else {
var chtnecolorw = (chtvcolor == 3)? chtnwidth + 2:chtnwidth + chtcwidth + 2;
var chtnecolorww = chtnecolorw - 1;
if(dallar('chtnecolor').style.width == '1px') {
dallar('chtnecolor').style.width = chtnecolorw + 'px';
if(chtncw == 1) dallar('chcontent').style.width = parseInt(parseInt(dallar('chcontent').style.width) - chtnecolorww) + 'px';
dallar('neme').style.display = 'inline';
if(chtvcolor !== 3) dallar('cht_color').style.display = 'inline';
} else {
dallar('neme').style.display = 'none';
if(chtvcolor !== 3) dallar('cht_color').style.display = 'none';
dallar('chtnecolor').style.width = '1px';
if(chtncw == 1) dallar('chcontent').style.width = parseInt(parseInt(dallar('chcontent').style.width) + chtnecolorww) + 'px';
}}}
function cht_ex(n) {
if(!n) cht_en();
else {
n -= 1;
var txta = new Array(";ico",";b",";i",";u",";exit",";re",";bak",";admin",";nick","상대방// 이 상태에서 엔터하면 해제됨",";color","","",";pause",";clear",";head");
var txtb = new Array("이모티콘","글자 굵게","글자 기울게","글자에 밑줄","채팅방 퇴장","새로고침","저장된 기록 보기","관리자 기능","닉네임 열기","귓속말 해제","색상선택상자","닉네임란","본문란","스크롤 정지","본문 지움","채팅방 헤드 감춤/드러냄");
if(chtvcolor == 2 && n == 8) n = 10;
var txtc = '<b>' + txtb[n] + '<\/b>';
if(n == 11) dallar('neme').focus();
else if(n == 12) dallar('chcontent').focus();
else {
if(fbdyw > 251) txtc += '&nbsp; 입력창에서 " ' + txta[n] + '"';
else if(fbdyw > 201) txtc += '&nbsp; ' + txta[n];
}
cht_en(txtc);
}}
function cht_gg() {
if(chtreload != 5 && dallar('cht_gout').value != '9') {
var ckk = new Date().getTime() - parseInt(dallar('cht_ntim').value);
if(ckk > 20000) {
if(chtreload == 1) {tout();location.reload();}
else if(chtreload == 2) cht_inn("새로고침이 필요합니다. <input type='button' value='새로고침' class='cht_button' onclick='tout();location.reload();' />",3000,"cht_alert","");
else if(confirm('새로고침이 필요합니다. 새로고침하시겠습니까')) {tout();location.reload();}
}
if(ckk > 10000) {
clearTimeout(chtnextread);
chtnextread = setTimeout("cht_go('read')", chtrefresh);
}}
if(chtreload != 5) setTimeout('cht_gg()', 3500);
}
function cht_emodr(n) {
var emdiv = dallar('cht_fico').getElementsByTagName('div');
if(emdiv.length > 1) {
n = parseInt(n) -1;
for(var m = emdiv.length - 1;m >= 0;m--) {
if(m == n) emdiv[m].style.display = '';
else emdiv[m].style.display = 'none';
}}}
function cht_setup() {
chtedir = (chtemtc)? chtemtc+ "widgets/srchat/":"";
chtbx = 0;
cht_obj = dallar('chcontent');
cht_obj.value = '';
if(chtlgnfw == null) chtlgnfw = dallar('cht_ban').contentWindow;
dallar('cht_AA').style.overflowX='hidden';
dallar('cht_ntim').value="0000000000a";
if(dallar('cht_OO').style.borderWidth != '1px') dallar('cht_gout').value='0';
dallar('cht_xtim').value='0';
if(cht_ico.length > 0) {
var femt = '';
var femtt = '';
var chtl = cht_ico.length;
for(var ii=1;ii < chtl;ii++) {
if(chtl > 2) {
femtt += "<input type='button' value=' " + cht_ico[ii][0].replace(/\//g,'') + "' class='cht_button' onclick='cht_emodr(" + ii + ")' /> ";
if(ii == 1) femt += "<div>";
else femt += "<div style='display:none'>";
}
for(var i=cht_ico[ii].length -1;i > 0;i--) {
femt += "<img src='" + chtedir + "emoticon" + cht_ico[ii][0] + cht_ico[ii][i] + "' alt='' onclick=\"cht_tag('" + ii + "," + i + "')\" />";
}
if(chtl > 2) femt += "<\/div>";
}
if(femt != '') dallar('cht_fico').innerHTML = "<dl style='background:" + ((chtisblack == 1)? '#000000':'#ffffff') + ";margin:0'>"+ femtt + femt + "</dl>";
dallar('cht_fico').style.width = fbdyw + 'px';
if(!chtvtime) fbdyw += 51;
dallar('cht_EE').style.width = (fbdyw - 81) + 'px';
dallar('cht_fico').style.display = 'none';
}
setTimeout("if(dallar('cht_AA').firstChild) cht_ntm(dallar('cht_AA').firstChild)",50);
if(document.cookie) {
var chtcllt = document.cookie.indexOf('cht_callt=');
if(chtcllt != -1) {chtcllt = document.cookie.substr(chtcllt + 10,13);dallar('cht_callt').value = chtcllt;
}}
cht_go('read');
setTimeout('cht_gg()',5000);
if(chtupdown == 0) setTimeout("dallar('cht_AA').scrollTop = dallar('cht_AA').scrollHeight;",1000);
var shh = String(dallar('cht_HH').style.height);
if(shh.indexOf('%') != -1 || shh.indexOf('mm') != -1) {dallar('cht_HH').style.height = document.documentElement.clientHeight*parseInt(shh)/100 + "px";}
shh = String(dallar('cht_HH').style.width);if(shh.indexOf('mm') != -1) dallar('cht_HH').style.width = parseInt(shh) + '%';
shh = String(dallar('cht_AA').style.height);if(shh.indexOf('mm') != -1) dallar('cht_AA').style.height = parseInt(shh) + '%';
shh = String(dallar('cht_DD').style.width);if(shh.indexOf('mm') != -1) dallar('cht_DD').style.width = parseInt(shh) + '%';
shh = String(dallar('cht_DD').style.height);if(shh.indexOf('mm') != -1) dallar('cht_DD').style.height = parseInt(shh) + '%';
shh = String(dallar('cht_DD').style.width);if(shh.indexOf('mm') != -1) dallar('cht_DD').style.width = parseInt(shh) + '%';

var chtstyle = cht_iscookie(0);
dallar('cht_variable').value = 'chttalert=' + chttalert + ';chtualert=' + chtualert + ';chtunload=' + chtunload + ';chtuadmico=' + chtuadmico + ';chtip="' + chtip + '";chtisbk=' + chtisbk + ';chtreload=' + chtreload + ';chtview=' + chtview + ';chtvimg=' + chtvimg + ';chtimgmw=' + chtimgmw + ';chtrefresh=' + chtrefresh + ';chtismobile=' + chtismobile + ';chtinterval=' + chtinterval + ';chtuimg=' + chtuimg + ';chtiimg=' + chtiimg + ';chtupdown=' + chtupdown + ';chtwrtpst=' + chtwrtpst + ';chtmyself=' + chtmyself + ';chtimgmk=' + chtimgmk + ';chtcallt=' + chtcallt + ';chtmkadmin=' + chtmkadmin + ';cht_isadmin=' + cht_isadmin + ';chtpnck=' + chtpnck + ';chtbtcnt=' + chtbtcnt + ';chtread=' + chtread + ';chtchange=' + chtchange + ';fbdyw=' + fbdyw + ';chtisblack=' + chtisblack + ';chtusrinout=' + chtusrinout + ';chtvban=' + chtvban + ';chtncw=' + chtncw + ';chtafst="' + chtafst + '";chtvcolor=' + chtvcolor + ';chtxw="' + chtxw + '";chtxh="' + chtxh + '";chtnwidth=' + chtnwidth + ';chtcwidth=' + chtcwidth + ';chtvdate=' + chtvdate + ';chtvtime=' + chtvtime + ';';
setTimeout("cht_stvariable()",120000);
if(chtstyle != -1 && (dallar('cht_color').title == '' || dallar('cht_color').title != 'disabled')) {
dallar('cht_color').value = chtstyle;
setTimeout("cht_fbcolr(9)",50);
}}
function cht_stvariable() {
eval(dallar('cht_variable').value);
setTimeout("cht_stvariable()",120000);
}
function cht_iscookie(isc) {
var chtstyle = document.cookie.indexOf('cht_sty4=');
if(chtstyle != -1) chtstyle = document.cookie.substr(chtstyle + 9,2);
if(isc != 0) {if(isc != chtstyle) document.cookie = "cht_sty4 = " + isc;
} else return chtstyle;
}
function cht_deltt(ths) {
setTimeout("cht_delt(cht_this.parentNode);cht_this = null;",500);
}
function cht_delt(ths) {
if(ths && ths.id != 'cht_none') ths.parentNode.removeChild(ths);
}
function cht_11chat(ip,thsi) {
if(ip && chtaacc == 2) cht_aadd(1);
if(dallar('cht_JJ').style.width != '1px') chtipths();
cht_obj.value= ip + thsi + "//whisper//11chat";
cht_go('rpage');
cht_inn('"' + thsi + '"님에게 1:1 대화를 신청했습니다',2000,'cht_alert','');
}
function chtipthss() {
if(dallar('cht_JJ').style.width != '1px') {
dallar('cht_JJ').firstChild.style.display = 'none';
dallar('cht_JJ').style.width = '1px';
dallar('chcontent').style.width = parseInt(parseInt(dallar('chcontent').style.width) + 41) + 'px';
} else {
dallar('chcontent').style.width = parseInt(parseInt(dallar('chcontent').style.width) - 41) + 'px';
dallar('cht_JJ').style.width = '42px';
dallar('cht_JJ').firstChild.style.display = 'block';
}}
function chtipths(ip,thsi) {
if(ip && chtaacc == 2) cht_aadd(1);
if(ip && thsi) {
if(dallar('cht_JJ').style.width != '1px') chtipths();
else {
dallar('cht_wip').value = ip + thsi;
setTimeout("cht_obj.value = '" + thsi + "//'",200);
chtipthss();
}} else if(ip) {
if(dallar('cht_JJ').style.width != '1px') chtipths();
var ctime = new Date().getTime();
var dtime = ctime - parseInt(dallar('cht_callt').value);
if(chtcallt != 0 && dtime < chtcallt) cht_inn('알림음 호출 시간간격 '+  ((chtcallt - dtime)/1000) + '초/' + (chtcallt/1000) + '초 남았습니다',2000,'cht_alert','');
else {
dallar('cht_callt').value = ctime;
document.cookie = "cht_callt = " + ctime;
cht_obj.value = ip;
cht_go('alert');
}} else {
if(cht_obj.value.indexOf('//') != -1) cht_obj.value = '';
cht_delt(dallar(dallar('cht_wip').value.substr(0,12)));
dallar('cht_wip').value = '';
if(dallar('cht_JJ').style.width != '1px') chtipthss();
}
cht_obj.focus();
}
function cht_nxt_html(val) {
if(cht_nxthtml !== null) {
cht_nxthtml.style.display = 'none';
cht_nxthtml.innerHTML = '';
cht_nxthtml = null;
}
if(chtaacc == 2) cht_aadd(1);
if(val) {
val.display = 'none';
val.innerHTML = '';
}}
function cht_whspr(ths,n,m) {
if(chtsrchat.indexOf("__") != -1) return '';
var ip = '';
if(n == 3) {ths = dallar('cht_' + chtip);m = m.parentNode.nextSibling;}
var chtnx_thtml = ((n === 2 || n == 4)? ths.nextSibling:m);
if(cht_nxthtml == chtnx_thtml || chtnx_thtml.innerHTML != '' || chtnx_thtml == cht_nxth_tml || cht_nxthtml !== null) {cht_nxth_tml = null;cht_nxt_html(chtnx_thtml);} else {
if(ths.tagName.toLowerCase() == 'b') ip = ths.previousSibling.name.substr(4);
else ip = ths.id.substr(4);
var thsi = chtnxg(ths.innerHTML);
var nxthtml = "<ul class='nxtht'";
if(chtismobile > 0) nxthtml += " style='position:absolute;z-index:9'";
if(n == 3 || n == 4) {
nxthtml += "><li><a onmousedown=\"cht_away()\"><span>&bull;<\/span> 자리비움 " + ((ths.title != '')? '해제':'설정') + "</a><\/li>";
} else {
nxthtml += "><li><a onmousedown=\"chtipths('" + ip + "','" + thsi + "')\"><span>&bull;<\/span> 귓속말</a><\/li><li><a onmousedown=\"cht_11chat('" + ip + "','" + thsi + "')\"><span>&bull;<\/span> 1:1 대화신청<\/a><\/li>";
if(chtualert != 5) nxthtml += "<li><a onmousedown=\"chtipths('" + ip + thsi + "','')\"><span>&bull;<\/span> 알림음 호출<\/a><\/li>";
var imgsrc = '';
if(ths.firstChild && ths.firstChild.tagName && ths.firstChild.tagName.toLowerCase() == 'img') {
imgsrc = ths.firstChild.src;
if(!imgsrc || imgsrc.indexOf('/image_mark/') == -1) {
if(ths.childNodes[1] && ths.childNodes[1].tagName && ths.childNodes[1].tagName.toLowerCase() == 'img' && ths.childNodes[1].src && ths.childNodes[1].src.indexOf('/image_mark/') != -1) imgsrc = ths.childNodes[1].src;
else if(ths.lastChild && ths.lastChild.tagName && ths.lastChild.tagName.toLowerCase() == 'img' && ths.lastChild.src && ths.lastChild.src.indexOf('/image_name/') != -1) imgsrc = ths.lastChild.src;
else imgsrc = '';
}
if(imgsrc != '') {
imgsrc = imgsrc.substr(imgsrc.lastIndexOf('/') + 1);
imgsrc = imgsrc.substr(0,imgsrc.length - 4);
if(!!imgsrc) nxthtml += "<li><a onmousedown=\"window.open('" + chtemtc + "index.php?module=communication&act=dispCommunicationSendMessage&receiver_srl=" +imgsrc + "','_blank','location=no,resizable=yes,status=no,scrollbars=yes,toolbar=no,menubar=no,width=800px,height=600px');\"><span>&bull;<\/span> 쪽지 보내기<\/a><\/li>";
}}
if(cht_isadmin != 0) {nxthtml += "<li><a onmousedown=\"cht_kout('dumb_" + ip + "','" + thsi + "',4)\"><span>&bull;<\/span> 글쓰기 차단/해제<\/a><\/li><li><a onmousedown=\"cht_kout('" + ip + "','" + thsi + "',3)\"><span>&bull;<\/span> 강퇴<\/a><\/li><li><a onmousedown=\"cht_obj.value='" + ip + "'\"><span>&bull;<\/span> IP 보기<\/a><\/li>";
if(cht_isadmin == 2 && chtmkadmin) nxthtml += "<li><a onmousedown=\"cht_kout('adm_" + ip + "','" + thsi + "',5)\"><span>&bull;<\/span> 관리자로 지명<\/a><\/li>";
}}
nxthtml += "<\/ul>";
cht_imopn = true;
cht_nxthtml = chtnx_thtml;
cht_nxth_tml = chtnx_thtml;
chtnx_thtml.innerHTML = nxthtml;
chtnx_thtml.style.display = 'block';
chtnx_thtml.style.margin = '0';
if(n !== 2) return 1;
else if(chthorizon == 'v' && chtaacc != 2) cht_aadd(2);
}}
function cht_kout(xban, xnick, xnum) {
if(cht_isadmin != 0){
if(chtisbk) var chtlgnf = document.logox;
else var chtlgnf = chtlgnfw.document.logox;
if((xnum === 3 && confirm(xnick + "님을 강퇴합니다")) || (xnum === 4 && confirm(xnick + "님의 글쓰기를 차단/차단해제합니다.")) || (xnum === 5 && confirm(xnick + "님을 관리자로 추가 지명합니다."))) {
chtlgnf.ban.value = xban;
chtlgnf.nick.value = xnick;
} else chtlgnf.delf.value = xnick;
chtlgnf.submit();
}}
function tout() {
dallar('cht_gout').value = '1';
}
function chtaablk() {
if(chtblk == 1 || new Date().getTime() -  chtaablkc > 10000) {
dallar('cht_AA').style.visibility = 'visible';
document.title = chttitle;
chtblk = 1;
} else {
dallar('cht_AA').style.visibility = (dallar('cht_AA').style.visibility == 'hidden')? 'visible':'hidden';
document.title = (document.title != chttitle)? chttitle:chtctitle;
setTimeout("chtaablk()",200);
}}
function chtonclick(n) {
if(cht_imopn) {cht_imgview(0);chtblk = 1;}
}
function chtxdel(ths,xno) {
if(confirm("'" + ths.parentNode.innerHTML.replace(/<[^>]+>/g,"").replace(/&[ag]t;/,"::") + "' 이 글을 삭제하시겠습니까")) {
var chtlgnf = chtlgnfw.document.logox;
if(chtlgnf) {chtlgnf.dxno.value = xno;chtlgnf.submit();}
}}
function tinvert(r) {
var sel = document.getElementsByName('xbak[]');
if(r) r = parseInt(sel.length/2); else r = sel.length - 1;
for(var i = r; i >= 0;i--) {
if(sel[i].checked) sel[i].checked = false;
else sel[i].checked = true;
}}
function finvert(r) {
var sel = document.getElementsByName('xbak[]');
var del = document.getElementsByClassName('cx');
if(r) r = parseInt(sel.length/2); else r = sel.length - 1;
for(var i = r; i >= 0;i--) {
if(del[i] && del[i].getElementsByTagName('input').length >= 2) {
if(sel[i].checked) sel[i].checked = false;
else sel[i].checked = true;
} else sel[i].checked = false;
}}
function fsubmit() {
document.bakform.torf.value = 1;
var sel = document.getElementsByName('xbak[]');
var del = document.getElementsByClassName('cx');
var fel;
for(i = sel.length - 1; i >= 0;i--) {
sel[i].value = '';
if(sel[i].checked == true && del[i]) {
fel = del[i].getElementsByTagName('input')[1];
if(!!fel) sel[i].value = chtdelff(fel.nextSibling);
}}
ssubmit();
}
function ssubmit() {
var sel = document.getElementsByName('xbak[]');
var xel = '';
for(i = sel.length - 1; i >= 0;i--) {
if(sel[i].checked) {
xel += "_" + sel[i].title;
}}
document.bakform.dnox.value = xel.slice(1);
document.bakform.submit();
}
function chtonkeydown(e) {
if(typeof(event) == "undefined") {var keycode = e.which;var etarget = e.target;}
else {var keycode = event.keyCode;var etarget = event.srcElement;}
if(keycode =='13' && etarget && etarget.id == 'chcontent') cht_go('rpage');
}
function mkdumb(mkd) {
if(mkd === 1) {
dallar('cht_UU').style.display = 'none';
dallar('cht_dumb').value = '1';
} else if(dallar('cht_dumb').value == '1') {
dallar('cht_UU').style.display = '';
dallar('cht_dumb').value = '0';
}}
var chtx, chty, chtry = 0;
function chtxy(e) {
if(typeof(event) == "undefined") {chtx = e.pageX;chty = e.pageY;}
else {chtx = event.clientX;chty = event.clientY;}
if(chtry !== 0) {
dallar("cht_fbdy").style.left = (chtx - chtry[0] + parseInt(chtry[2])) + "px";
dallar("cht_fbdy").style.top = (chty - chtry[1] + parseInt(chtry[3])) + "px";
}}
window.onbeforeunload = function(){if(!chtisbk && chtunload) {if(dallar('cht_gout').value == '0'){if(cht_go('out')){dallar('cht_gout').value = '9';if(navigator.appName == 'Opera') alert('접속을 종료합니다');else return "---";}}}}
window.onunload = function(){window.onbeforeunload();}
document.onmouseup = chtonclick;
document.onkeydown = chtonkeydown;