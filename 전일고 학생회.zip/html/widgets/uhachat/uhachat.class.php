<?php
  class uhachat extends WidgetHandler {
    function proc($args) {
      $logged_info = Context::get('logged_info');
      
      $obj = null;
      $obj->skins = $args->skin;
      $obj->code = $args->code;
      $obj->uha_height = $args->uha_height;
      if(empty($obj->uha_height)){$obj->uha_height = '100%';}
      
      if(!empty($args->anonymous) && isset($logged_info->nick_name)){
        $obj->name = $logged_info->nick_name;
        $obj->key = md5(trim($obj->name).trim($args->key));
      }
      else{
        $obj->name = null;
        $obj->key = null;
      }
      
      if( (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['HTTP_X_FORWARDED_PROTO'] == "https"){$obj->proto = "https://";}else{$obj->proto = "http://";}

      $act = Context::get('act');
      $tpl_path = sprintf('%sskins/%s', $this->widget_path, $obj->skins);
      $tpl_file = ($act == "dispPageAdminContentModify" || $act == "procWidgetGenerateCodeInPage")? "a" : "b";
      
      $obj->css_tpl_path = getUrl().$tpl_path;
      if($obj->proto == "https://"){$obj->css_tpl_path = str_replace("http://", "https://", $obj->css_tpl_path);}
      Context::set('uhachat',$obj);

      $oTemplate = &TemplateHandler::getInstance();
      return $oTemplate->compile($tpl_path, $tpl_file);
    }
  }
?>
