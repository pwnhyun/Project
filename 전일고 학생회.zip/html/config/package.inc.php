<?php
/* Copyright (C) NAVER <http://www.navercorp.com> */

define('_XE_PACKAGE_', 'XE');
define('_XE_LOCATION_', 'ko');
define('_XE_LOCATION_SITE_', 'http://www.xpressengine.com/');
define('_XE_DOWNLOAD_SERVER_', 'http://download.xpressengine.com/');
